Rename-Item pbrain-gomoku-ai pbrain-gomoku-ai.py

pyinstaller --onefile -n pbrain-gomoku-ai.exe pbrain-gomoku-ai.py